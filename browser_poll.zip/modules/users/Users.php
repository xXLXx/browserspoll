<?php

namespace modules\users;

class Users extends \yii\base\Module
{
    public $defaultRoute = 'users';
}