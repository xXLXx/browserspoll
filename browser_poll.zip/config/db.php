<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=browserpoll',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
